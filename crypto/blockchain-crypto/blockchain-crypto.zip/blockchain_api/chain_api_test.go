package blockchain_api

import (
	"blockchain-crypto/encrypt/ibve"
	"blockchain-crypto/types/curve/bls12381"
	"crypto/rand"
	"fmt"
	"testing"
)

func TestIBVE(t *testing.T) {
	msg, _ := gt.New().Rand(rand.Reader)
	sk, pk := Keygen()
	cipherTextBytes := Encrypt(pk, gt.ToBytes(msg))
	decMsg := Decrypt(sk, cipherTextBytes)
	fmt.Println(gt.FromBytes(decMsg))
	fmt.Println(msg)
	cipherText, err := new(ibve.CipherText).FromBytes(cipherTextBytes)
	if err != nil {
		return
	}
	sigma := g1.MulScalar(g1.New(), cipherText.C1, bls12381.NewFr().FromBytes(sk))
	fmt.Println(Verify(g1.ToCompressed(sigma),
		pk,
		g2.ToCompressed(cipherText.C2)))
}
