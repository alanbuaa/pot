package blockchain_api

import (
	"blockchain-crypto/encrypt/ibve"
	dleq "blockchain-crypto/proof/dleq/bls12381"
	mrpvss "blockchain-crypto/share/mrpvss/bls12381"
	"blockchain-crypto/types/curve/bls12381"
)

var (
	g1 = bls12381.NewG1()
	g2 = bls12381.NewG2()
	gt = bls12381.NewGT()
)

func Keygen() ([]byte, []byte) {
	sk, pk := ibve.Keygen()
	return sk.ToBytes(), g1.ToCompressed(pk)
}

func Encrypt(yBytes []byte, msgBytes []byte) []byte {
	y, err := g1.FromCompressed(yBytes)
	if err != nil {
		return nil
	}
	msg, err := gt.FromBytes(msgBytes)
	if err != nil {
		return nil
	}
	cipherText := ibve.Encrypt(y, msg)
	return cipherText.ToBytes()
}

func Decrypt(xBytes []byte, cipherTextBytes []byte) []byte {
	x := bls12381.NewFr().FromBytes(xBytes)
	cipherText, err := new(ibve.CipherText).FromBytes(cipherTextBytes)
	if err != nil {
		return nil
	}
	msg := ibve.Decrypt(x, cipherText)
	return gt.ToBytes(msg)
}

func Verify(sigmaBytes []byte, yBytes []byte, c2Bytes []byte) bool {
	sigma, err := g1.FromCompressed(sigmaBytes)
	if err != nil {
		return false
	}
	y, err := g1.FromCompressed(yBytes)
	if err != nil {
		return false
	}
	c2, err := g2.FromCompressed(c2Bytes)
	if err != nil {
		return false
	}
	return ibve.Verify(sigma, y, c2)
}

func CalcRoundShare(index uint32, hBytes []byte, cBytes []byte, shareCommitBytes []byte, shareBytes []byte) ([]byte, []byte, error) {
	h, err := g1.FromCompressed(hBytes)
	if err != nil {
		return nil, nil, err
	}
	c, err := g1.FromCompressed(cBytes)
	if err != nil {
		return nil, nil, err
	}
	shareCommit, err := g1.FromCompressed(shareCommitBytes)
	if err != nil {
		return nil, nil, err
	}
	share := bls12381.NewFr().FromBytes(shareBytes)
	roundShare, roundShareProof, err := mrpvss.CalcRoundShare(index, h, c, shareCommit, share)
	return g1.ToCompressed(roundShare), roundShareProof.ToBytes(), err
}

func VerifyRoundShare(index uint32, hBytes []byte, cBytes []byte, shareCommitBytes []byte, roundShareBytes []byte, roundShareProofBytes []byte) bool {
	h, err := g1.FromCompressed(hBytes)
	if err != nil {
		return false
	}
	c, err := g1.FromCompressed(cBytes)
	if err != nil {
		return false
	}
	shareCommit, err := g1.FromCompressed(shareCommitBytes)
	if err != nil {
		return false
	}
	roundShare, err := g1.FromCompressed(roundShareBytes)
	if err != nil {
		return false
	}
	roundShareProof, err := new(dleq.Proof).FromBytes(roundShareProofBytes)
	if err != nil {
		return false
	}
	return mrpvss.VerifyRoundShare(index, h, c, shareCommit, roundShare, roundShareProof)
}

func RecoverRoundSecret(threshold uint32, roundSharesBytes [][]byte) []byte {
	roundShareNum := len(roundSharesBytes)
	roundShares := make([]*bls12381.PointG1, roundShareNum)
	var err error
	for i := 0; i < roundShareNum; i++ {
		roundShares[i], err = g1.FromCompressed(roundSharesBytes[i])
		if err != nil {
			return nil
		}
	}
	roundSecret := mrpvss.RecoverRoundSecret(threshold, roundShares)
	return g1.ToCompressed(roundSecret)
}
